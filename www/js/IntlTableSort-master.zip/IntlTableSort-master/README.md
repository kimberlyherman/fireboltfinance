# IntlTableSort

HTML 5.3 International Table Sorter

HTML 5.3: https://www.w3.org/TR/html53/

Compatible list:

Chrome 41+

Edge 12+

Firefox 44+

Internet Explorer 11+

Opera 25+

Safari 10+

Compatibility unknown:

DOM 4.1: https://www.w3.org/TR/dom41/
